# Annual Stocktaking — Edge Function V1

## 內容

- `supabase/config.toml`
- `supabase/functions/employee-login/index.ts`
- `supabase/functions/employee-login/deno.json`

這是第一版 Edge Function 原始碼，尚未部署，也不會自行啟用 Supabase Anonymous Sign-In。

## 功能

單一 `employee-login` 函數支援三種 action：

1. `login`：USER 工號登入；ADMIN／DEVELOPER 工號 + PIN 登入。
2. `bootstrap_pin`：首位 DEVELOPER 使用一次性初始化密鑰設定自己的 PIN，並完成 Auth UUID 綁定。
3. `initialize_employee_pin`：已登入的 DEVELOPER 替其他尚未設定 PIN 的 ADMIN／DEVELOPER 初始化 PIN。

PIN 使用 Argon2id（hash-wasm），參數：memory 65536 KiB、iterations 3、parallelism 1、hash length 32 bytes。

## 必要 Edge Function Secrets

部署前在 Supabase Dashboard > Edge Functions > Secrets 設定：

- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`
- `DEVELOPER_BOOTSTRAP_TOKEN`（僅首次初始化使用的高強度隨機密鑰）

**Service Role Key 和 DEVELOPER_BOOTSTRAP_TOKEN 絕不可放在前端、GitHub 或 ZIP 公開位置。**

`DEVELOPER_BOOTSTRAP_TOKEN` 建議使用至少 32 bytes 隨機值。首位 DEVELOPER 成功初始化後，立即從 Edge Function Secrets 移除或輪替此 Secret。不要在正式環境長期保留。

## 部署前置條件

1. Supabase Auth > Providers > Anonymous Sign-Ins 必須由專案管理者明確啟用；目前尚未啟用，這份程式不會替你開啟。
2. `employee_auth_security` 已有 5 位 ADMIN／DEVELOPER 的安全紀錄。
3. 已完成既有 Migration，且以下 RPC 的 EXECUTE 權限僅 service_role：
   - `bind_employee_auth`
   - `record_employee_pin_failure`
   - `record_employee_pin_success`
   - `set_employee_pin_hash`
4. 專案 Supabase URL、Anon Key 必須與前端 config.js 相同。

## 部署指令

需要 Supabase CLI 與已登入且連結正確的 Supabase 專案：

```bash
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase functions deploy employee-login
```

此專案的前端部署平台不會自動部署 Supabase Edge Function。

## 首位 DEVELOPER 初始化流程

1. 管理者先在 Supabase Dashboard 建立一次性 `DEVELOPER_BOOTSTRAP_TOKEN` Secret。
2. 前端先執行 `supabase.auth.signInAnonymously()` 取得匿名 Session。
3. 呼叫 Edge Function：

```javascript
const { data, error } = await supabase.functions.invoke("employee-login", {
  body: {
    action: "bootstrap_pin",
    employee_id: "DEVELOPER工號",
    pin: "六位數PIN",
    bootstrap_token: "一次性初始化密鑰"
  }
});
```

4. 成功後立即移除／輪替 `DEVELOPER_BOOTSTRAP_TOKEN`。
5. 登出並以一般登入流程測試該 DEVELOPER 工號 + PIN。

初始化密鑰會透過 HTTPS 傳送，建議實際操作時由受控的管理端畫面輸入，不要寫入前端原始碼、網址、瀏覽器 localStorage 或 console log。

## 其他 ADMIN／DEVELOPER PIN 初始化

由已登入的 DEVELOPER Session 呼叫：

```javascript
const { data, error } = await supabase.functions.invoke("employee-login", {
  body: {
    action: "initialize_employee_pin",
    employee_id: "目標員工工號",
    pin: "目標員工六位數PIN"
  }
});
```

此 action 僅允許已綁定且啟用中的 DEVELOPER 呼叫；目標必須是啟用中的 ADMIN／DEVELOPER，且尚未設定 PIN。現有已設定 PIN 不可透過此 action 覆寫。

## 前端登入 Session

本 ZIP 已同步修正根目錄 `app.js`：先取得／建立 Anonymous Auth Session，再呼叫 `employee-login`；不再期待 Edge Function 回傳 access_token / refresh_token。Anonymous Auth Session 由前端建立並保留。Edge Function 不簽發、不回傳 access_token / refresh_token。

```javascript
const { data: sessionData, error: authError } =
  await supabase.auth.getSession();

if (!sessionData.session) {
  const { error } = await supabase.auth.signInAnonymously();
  if (error) throw error;
}

const { data, error } = await supabase.functions.invoke("employee-login", {
  body: { action: "login", employee_id: "六位工號", pin: "管理者PIN或省略" }
});
```

## 重要安全限制與待辦

- USER 僅工號登入是已核准的風險接受方案；知道工號者可能冒用。
- `bind_employee_auth()` 的 24 小時 cooldown 會套用於首次綁定與重新綁定。
- 此版尚未提供 DEVELOPER PIN 管理 UI；可先透過受控管理端呼叫 `initialize_employee_pin`，後續再建置管理介面。
- 此版沒有額外的 IP/device rate limit；現有資料庫 PIN lockout 已實作 5 次失敗後鎖定與遞增時間。若要增加 IP/device rate limit，需要另行設計可信任的代理 IP 來源與儲存策略。
- 目前 bootstrap 的一次性限制以「任何啟用中 DEVELOPER 已有 PIN hash」為判斷，另需在首次初始化後立即移除 bootstrap Secret。正式初始化應只由一位指定 DEVELOPER 執行，避免並行操作。
- 不要在正式環境用測試工號或弱 PIN 做初始化。
- 不要把此版本視為已完成上線驗收；必須先完成部署、匿名登入設定、端對端測試與安全檢查。


## 前端設定

編輯根目錄 `config.js`，只填入 Supabase Project URL 與公開 anon/publishable key。不可填入 Service Role Key 或 Bootstrap Token。

現有 ZIP 的相機功能仍是預覽階段，條碼解碼器尚未納入本次 Edge Function 範圍。
