import { createClient } from "@supabase/supabase-js";
import { argon2id, argon2Verify } from "hash-wasm";

type Employee = {
  employee_id: string;
  employee_name: string;
  role: "USER" | "ADMIN" | "DEVELOPER";
  is_active: boolean;
  auth_user_id: string | null;
};

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-developer-bootstrap-token",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (body: Record<string, unknown>, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

const isEmployeeId = (v: unknown): v is string =>
  typeof v === "string" && /^[0-9]{6}$/.test(v);
const isPin = (v: unknown): v is string =>
  typeof v === "string" && /^[0-9]{6}$/.test(v);

function getEnv(name: string): string {
  const value = Deno.env.get(name);
  if (!value) throw new Error(`Missing Edge Function secret: ${name}`);
  return value;
}

function constantTimeEqual(a: string, b: string): boolean {
  const encoder = new TextEncoder();
  const aa = encoder.encode(a);
  const bb = encoder.encode(b);
  let diff = aa.length ^ bb.length;
  const length = Math.max(aa.length, bb.length);
  for (let i = 0; i < length; i++) {
    diff |= (aa[i] ?? 0) ^ (bb[i] ?? 0);
  }
  return diff === 0;
}

async function makePinHash(pin: string): Promise<string> {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  return await argon2id({
    password: pin,
    salt,
    parallelism: 1,
    iterations: 3,
    memorySize: 65536,
    hashLength: 32,
    outputType: "encoded",
  }) as string;
}

async function callRpc<T>(
  admin: ReturnType<typeof createClient>,
  name: string,
  args: Record<string, unknown>,
): Promise<T> {
  const { data, error } = await admin.rpc(name, args);
  if (error) throw new Error(`RPC ${name} failed: ${error.message}`);
  return data as T;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }
  if (req.method !== "POST") return json({ success: false, code: "METHOD_NOT_ALLOWED" }, 405);

  try {
    const supabaseUrl = getEnv("SUPABASE_URL");
    const anonKey = getEnv("SUPABASE_ANON_KEY");
    const serviceRoleKey = getEnv("SUPABASE_SERVICE_ROLE_KEY");
    const authorization = req.headers.get("Authorization");
    if (!authorization?.startsWith("Bearer ")) {
      return json({ success: false, code: "AUTH_REQUIRED" }, 401);
    }

    // Validate the caller's JWT with Supabase Auth. Never trust a UUID supplied by the browser.
    const caller = createClient(supabaseUrl, anonKey, {
      auth: { persistSession: false, autoRefreshToken: false },
      global: { headers: { Authorization: authorization } },
    });
    const { data: authData, error: authError } = await caller.auth.getUser();
    if (authError || !authData.user) {
      return json({ success: false, code: "INVALID_SESSION" }, 401);
    }
    const authUserId = authData.user.id;

    const admin = createClient(supabaseUrl, serviceRoleKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    let body: Record<string, unknown>;
    try {
      body = await req.json();
    } catch {
      return json({ success: false, code: "INVALID_JSON" }, 400);
    }

    const action = body.action ?? "login";

    // -----------------------------------------------------------------------
    // First developer bootstrap: one-time secret, developer account only.
    // -----------------------------------------------------------------------
    if (action === "bootstrap_pin") {
      const employeeId = body.employee_id;
      const pin = body.pin;
      const suppliedToken = req.headers.get("x-developer-bootstrap-token") ??
        (typeof body.bootstrap_token === "string" ? body.bootstrap_token : "");
      const expectedToken = getEnv("DEVELOPER_BOOTSTRAP_TOKEN");

      if (!isEmployeeId(employeeId) || !isPin(pin) || !suppliedToken) {
        return json({ success: false, code: "INVALID_ARGUMENT" }, 400);
      }
      if (!constantTimeEqual(suppliedToken, expectedToken)) {
        return json({ success: false, code: "BOOTSTRAP_TOKEN_INVALID" }, 403);
      }

      const { data: target, error: targetError } = await admin
        .from("user_master")
        .select("employee_id,employee_name,role,is_active,auth_user_id")
        .eq("employee_id", employeeId)
        .maybeSingle();
      if (targetError) throw targetError;
      if (!target || !target.is_active || target.role !== "DEVELOPER") {
        return json({ success: false, code: "DEVELOPER_NOT_ELIGIBLE" }, 403);
      }

      // Bootstrap is allowed only while neither developer has a PIN configured.
      const { data: devs, error: devError } = await admin
        .from("user_master")
        .select("employee_id")
        .eq("role", "DEVELOPER")
        .eq("is_active", true);
      if (devError) throw devError;
      const developerIds = (devs ?? []).map((x: { employee_id: string }) => x.employee_id);
      const { data: securityRows, error: securityError } = await admin
        .from("employee_auth_security")
        .select("employee_id,pin_hash")
        .in("employee_id", developerIds);
      if (securityError) throw securityError;
      if ((securityRows ?? []).some((x: { pin_hash: string | null }) => !!x.pin_hash)) {
        return json({ success: false, code: "BOOTSTRAP_ALREADY_USED" }, 409);
      }

      if (target.auth_user_id && target.auth_user_id !== authUserId) {
        return json({ success: false, code: "DEVELOPER_ALREADY_BOUND_TO_ANOTHER_SESSION" }, 409);
      }

      // Bind first. If hash creation/storage fails, the same Auth UUID can retry safely.
      const bind = await callRpc<Record<string, unknown>>(admin, "bind_employee_auth", {
        p_employee_id: employeeId,
        p_new_auth_user_id: authUserId,
      });
      if (bind?.success !== true) {
        return json({ success: false, code: String(bind?.reason ?? "BIND_FAILED") }, 409);
      }

      const hash = await makePinHash(pin);
      const pinResult = await callRpc<Record<string, unknown>>(admin, "set_employee_pin_hash", {
        p_employee_id: employeeId,
        p_pin_hash: hash,
        p_action_type: "PIN_SET",
      });
      if (pinResult?.success !== true) {
        return json({ success: false, code: String(pinResult?.reason ?? "PIN_SETUP_FAILED") }, 500);
      }

      return json({
        success: true,
        action: "BOOTSTRAP_COMPLETE",
        employee_id: target.employee_id,
        employee_name: target.employee_name,
        role: target.role,
        message: "首位 DEVELOPER PIN 已設定。請立即停用 DEVELOPER_BOOTSTRAP_TOKEN。",
      });
    }

    // -----------------------------------------------------------------------
    // An authenticated developer initializes another privileged employee PIN.
    // -----------------------------------------------------------------------
    if (action === "initialize_employee_pin") {
      const employeeId = body.employee_id;
      const pin = body.pin;
      if (!isEmployeeId(employeeId) || !isPin(pin)) {
        return json({ success: false, code: "INVALID_ARGUMENT" }, 400);
      }

      const { data: actor, error: actorError } = await admin
        .from("user_master")
        .select("employee_id,role,is_active")
        .eq("auth_user_id", authUserId)
        .maybeSingle();
      if (actorError) throw actorError;
      if (!actor || !actor.is_active || actor.role !== "DEVELOPER") {
        return json({ success: false, code: "DEVELOPER_AUTHORIZATION_REQUIRED" }, 403);
      }

      const { data: target, error: targetError } = await admin
        .from("user_master")
        .select("employee_id,employee_name,role,is_active")
        .eq("employee_id", employeeId)
        .maybeSingle();
      if (targetError) throw targetError;
      if (!target || !target.is_active || !["ADMIN", "DEVELOPER"].includes(target.role)) {
        return json({ success: false, code: "TARGET_NOT_ELIGIBLE" }, 404);
      }

      const { data: security, error: secError } = await admin
        .from("employee_auth_security")
        .select("pin_hash")
        .eq("employee_id", employeeId)
        .maybeSingle();
      if (secError) throw secError;
      if (security?.pin_hash) {
        return json({ success: false, code: "PIN_ALREADY_INITIALIZED" }, 409);
      }

      const hash = await makePinHash(pin);
      const result = await callRpc<Record<string, unknown>>(admin, "set_employee_pin_hash", {
        p_employee_id: employeeId,
        p_pin_hash: hash,
        p_action_type: "PIN_SET",
      });
      if (result?.success !== true) {
        return json({ success: false, code: String(result?.reason ?? "PIN_SETUP_FAILED") }, 500);
      }

      return json({
        success: true,
        action: "PIN_INITIALIZED",
        employee_id: target.employee_id,
        employee_name: target.employee_name,
        role: target.role,
      });
    }

    // -----------------------------------------------------------------------
    // Standard login.
    // -----------------------------------------------------------------------
    if (action !== "login") {
      return json({ success: false, code: "UNKNOWN_ACTION" }, 400);
    }

    const employeeId = body.employee_id;
    const pin = body.pin;
    if (!isEmployeeId(employeeId)) {
      return json({ success: false, code: "INVALID_EMPLOYEE_ID" }, 400);
    }

    const { data: employee, error: employeeError } = await admin
      .from("user_master")
      .select("employee_id,employee_name,role,is_active,auth_user_id")
      .eq("employee_id", employeeId)
      .maybeSingle();
    if (employeeError) throw employeeError;
    if (!employee || !employee.is_active) {
      return json({ success: false, code: "EMPLOYEE_NOT_FOUND_OR_INACTIVE" }, 404);
    }

    if (!["USER", "ADMIN", "DEVELOPER"].includes(employee.role)) {
      return json({ success: false, code: "INVALID_EMPLOYEE_ROLE" }, 403);
    }

    if (employee.role === "ADMIN" || employee.role === "DEVELOPER") {
      const { data: security, error: secError } = await admin
        .from("employee_auth_security")
        .select("pin_hash,failed_attempts,locked_until")
        .eq("employee_id", employeeId)
        .maybeSingle();
      if (secError) throw secError;

      if (!security?.pin_hash) {
        return json({ success: false, code: "PIN_NOT_INITIALIZED" }, 409);
      }
      if (security.locked_until && new Date(security.locked_until).getTime() > Date.now()) {
        return json({
          success: false,
          code: "PIN_LOCKED",
          locked_until: security.locked_until,
        }, 423);
      }
      if (!isPin(pin)) {
        return json({ success: false, requires_pin: true, code: "PIN_REQUIRED" }, 200);
      }

      let validPin = false;
      try {
        validPin = await argon2Verify({ password: pin, hash: security.pin_hash });
      } catch {
        return json({ success: false, code: "PIN_HASH_INVALID" }, 500);
      }

      if (!validPin) {
        const failure = await callRpc<Record<string, unknown>>(
          admin,
          "record_employee_pin_failure",
          { p_employee_id: employeeId },
        );
        return json({
          success: false,
          code: failure?.locked === true ? "PIN_LOCKED" : "PIN_INVALID",
          locked_until: failure?.locked_until ?? null,
          failed_attempts: failure?.failed_attempts ?? null,
        }, failure?.locked === true ? 423 : 401);
      }

      const success = await callRpc<Record<string, unknown>>(
        admin,
        "record_employee_pin_success",
        { p_employee_id: employeeId },
      );
      if (success?.success !== true) {
        return json({ success: false, code: "PIN_SUCCESS_RECORD_FAILED" }, 500);
      }
    }

    // USER accounts intentionally use employee-ID-only access per approved policy.
    const bind = await callRpc<Record<string, unknown>>(admin, "bind_employee_auth", {
      p_employee_id: employeeId,
      p_new_auth_user_id: authUserId,
    });
    if (bind?.success !== true) {
      return json({ success: false, code: String(bind?.reason ?? "BIND_FAILED") }, 409);
    }

    return json({
      success: true,
      employee_id: employee.employee_id,
      employee_name: employee.employee_name,
      role: employee.role,
      binding_action: bind.action ?? null,
    });
  } catch (error) {
    console.error("employee-login error:", error);
    return json({ success: false, code: "INTERNAL_ERROR", message: "登入服務發生錯誤，請稍後再試。" }, 500);
  }
});
